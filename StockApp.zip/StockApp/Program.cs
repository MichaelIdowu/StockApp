﻿///Author: Dr Michael A. Idowu \n
///Purpose: A program (solution) to the Super Simple Stock Market challenge posed by JPMorgan Chase & Co.\n
///Language: C# \n
///Date: March 2016 \n
///Copyright 2016, Michael A. Idowu \n

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Collections;
using System.Collections.Specialized;

///Application class for capturing all trade and trading data: Trading Class - called from the Application.Main block\n
///Entity-Relationship (ER) Model to be used: StockRegister<TSymbol,TType,TLastDividend,TParValue,TFixedDividend> Class - to - StockTransaction<TSymbolSource,TSymbolTarget,TTradeIndicator,TQty,TPrice,TTimeStamp> Class\n
///Description of the ER Model Relationship: Stock - to - Trade Transactions\n
///Xteristic of the ER Model: 1-to-Many relationship

namespace StockApp 
{
    ///Define the two main stock types
    public enum StockType
    {
        Common, 
        Preferred
    }

    ///Define the two main transaction indicators
    public enum TradeIndicator
    {
        Buy, 
        Sell
    }

    ///Define the main fields of the Global Beverage Corporation Exchange master table
    public enum StockQueryField
    {
        Symbol, 
        Type,
        LastDividend,
        FixedDividend,
        ParValue
    }

    /// Define a generic class for capturing and recording all trade transactions
    /// 

    class StockTransaction<TSymbolSource, 
                           TSymbolTarget, 
                           TTradeIndicator, 
                           TQty, 
                           TPrice, 
                           TTimeStamp> 
    {
        public TSymbolSource symSource;
        public TSymbolTarget symTarget;
        public TTradeIndicator indicator;
        public TQty qty;
        public TPrice price;
        public TTimeStamp time;

        ///Define the constructor class
        public StockTransaction(TSymbolSource source, 
                                TSymbolTarget target, 
                                TTradeIndicator indc, 
                                TQty qno, 
                                TPrice pr, 
                                TTimeStamp t)
        {
            symSource = source;
            symTarget = target;
            indicator = indc;
            qty = qno;
            price = pr;
            time = t;
        }

        ///useful for reporting all parameters in query
        internal string GetParameters() 
        {
            if (indicator.Equals(TradeIndicator.Buy))
            {
                return symSource + " bought " 
                                 + qty.ToString()
                                 + " shares from "
                                 + symTarget 
                                 + " at the cost of " 
                                 + price.ToString()
                                 + "/share on "
                                 + time.ToString();
            }
            else
            {
                return symSource + " sold " 
                                 + qty.ToString() 
                                 + " shares to " 
                                 + symTarget 
                                 + " at the cost of " 
                                 + price.ToString() 
                                 + "/share on " 
                                 + time.ToString();
            }
        }

        ///useful for reading and reporting trade transactions in query
        internal StockTransaction<TSymbolSource,  
                                  TSymbolTarget, 
                                  TTradeIndicator, 
                                  TQty, 
                                  TPrice, 
                                  TTimeStamp> 
         ReadTransaction()
        {
            StockTransaction<TSymbolSource, 
                             TSymbolTarget, 
                             TTradeIndicator, 
                             TQty, 
                             TPrice, 
                             TTimeStamp> 
            st = new StockTransaction<TSymbolSource, 
                                     TSymbolTarget, 
                                     TTradeIndicator, 
                                     TQty, 
                                     TPrice, 
                                     TTimeStamp>(symSource, symTarget, indicator, qty, price, time);
            ///reporting parameters to the console
            Console.WriteLine(GetParameters()); 

            return st;
        }
    }

    
    /// <summary>
    /// Define the register class;\n
    /// each stock is represented by this class.\n
    /// Note: StockRegister's relation to StockTransaction is 1-to-many \n
    /// xterised by the TransactionTable list variable \n
    /// </summary>
    /// <typeparam name="TSymbol"></typeparam>
    /// <typeparam name="TType"></typeparam>
    /// <typeparam name="TLastDividend"></typeparam>
    /// <typeparam name="TParValue"></typeparam>
    /// <typeparam name="TFixedDividend"></typeparam>
    class StockRegister<TSymbol, 
                        TType, 
                        TLastDividend, 
                        TParValue, 
                        TFixedDividend>
    {
        public TSymbol symbol;
        public TType type;
        public TLastDividend lastDividend;
        public TParValue parValue;
        public TFixedDividend fixedDividend;

        public double geometricMean;
        public double volumeWeightedPrice;

        ///Create a list variable for linking up with the StockTransaction class
        public List<StockTransaction<string, string, TradeIndicator, double, double, DateTime>> TransactionTable;
        
        ///... the constructor class
        public StockRegister(TSymbol symb, 
                             TType typ, 
                             TLastDividend ldiv, 
                             TParValue parval, 
                             TFixedDividend fdiv)
        {
            symbol = symb;
            type = typ;
            lastDividend = ldiv;
            parValue = parval;
            fixedDividend = fdiv;

            ///for clearing (resetting) the TransactionTable list
            ResetTransactionTable(); 
        }

        ///sample transaction entries for illustrating trade recording
        public void UseSampleTransactions() 
        {
            ///Create sample trade transactions to use ...
            TransactionTable.Add(new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                                (symbol.ToString(), "TEA", TradeIndicator.Buy,  55,  5, DateTime.Now ));
            TransactionTable.Add(new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                                (symbol.ToString(), "POP", TradeIndicator.Sell,  70,  15, DateTime.Now));
            TransactionTable.Add(new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                                (symbol.ToString(), "ALE", TradeIndicator.Buy,   15,  25, DateTime.Now));
            TransactionTable.Add(new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                                (symbol.ToString(), "GIN", TradeIndicator.Sell,  45,  20, DateTime.Now));
            TransactionTable.Add(new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                                (symbol.ToString(), "JOE", TradeIndicator.Buy, 65, 10, DateTime.Now));
        }

        public void ResetTransactionTable()
        {
            TransactionTable = new List<StockTransaction<string, string, TradeIndicator, double, double, DateTime>>();
        }

        ///Create a method to read from the TransactionTable based on the stock symbol,
        ///the returned object is a list of StockTransaction
        public List<StockTransaction<string, string, TradeIndicator, double, double, DateTime>> 
        QueryTransactions()
        {
            var TransactionRecords = 
                from transaction
                in TransactionTable
                where transaction.symSource == symbol.ToString() 
                select transaction.ReadTransaction();

            List<StockTransaction<string, string, TradeIndicator, double, double, DateTime>> 
                listTrans = new List<StockTransaction<string, string, TradeIndicator, double, double, DateTime>>();
            
            foreach (var transaction in TransactionRecords)
            {
                listTrans.Add(transaction);
            }

            return listTrans;
        }


        /// <summary>
        /// for writing to the console
        /// </summary>
        public void Echo() 
        {
            if (type.ToString() == "0")//i.e. if common stock
            {
                Console.Write("Symbol: {0}, Type: {1}, Last Dividend: {2}, Par Value: {3} \n", 
                    symbol, type, lastDividend, parValue);
            }
            else
            {
                Console.Write("Symbol: {0}, Type: {1}, Last Dividend: {2}, Fixed Dividend: {3}, Par Value: {4} \n",
                    symbol, type, lastDividend, fixedDividend, parValue);
            }
        }

        ///... method for calculating the dividend yield
        public double CalculateDividendYield(double price)
        {
            double dy = 0; 
            if (type.Equals(StockType.Common))
            {
                dy = double.Parse(lastDividend.ToString()) / price;
            }
            else
            {
                dy = double.Parse(fixedDividend.ToString())*double.Parse(parValue.ToString()) / price;
            }
            return dy;
        }

        ///... method for calculating the P/E ratio as indicated
        public double CalculatePEratio(double price)
        {
            double per = double.Parse(lastDividend.ToString()) > 0 ? 
                        price / double.Parse(lastDividend.ToString()) : -1;
            return per;
        }
        
        ///The GetParameters and ReadRegister class serve in capturing parameters 
        ///and StockRegister objects, respectively 
        internal string GetParameters()
        {
            if (type.Equals(StockType.Common))
            {
                return    "Symbol: " + symbol 
                        + ", Type: Common, Last Dividend: " + lastDividend 
                        + ", Par Value: " + parValue;
            }
            else
            {
                return "Symbol: " + symbol 
                    + ", Type: Preferred, Last Dividend: " + lastDividend 
                    + ", Par Value: " + parValue;
            }
        }

        internal StockRegister<TSymbol, TType, TLastDividend, TParValue, TFixedDividend> ReadRegister()
        {
            StockRegister<TSymbol, TType, TLastDividend, TParValue, TFixedDividend> sr = 
                new StockRegister<TSymbol, TType, TLastDividend, TParValue, TFixedDividend>
                    (symbol, type, lastDividend, parValue, fixedDividend);

            return sr;
        }

    }   
    

    ///Creating the main class for controlling and regulating the stock trade/trading application logic \n
    ///Encapsulates an array of the StockRegister; each StockRegister uniquely represents a stock \n
    class Trading
    {
        public StockRegister<string, StockType, double, double, double>[] stockTable;

        ///Constructor definition 1
        public Trading(StockRegister<string, StockType, double, double, double>[] stTable)
        {
            ///Create stock master table
            stockTable = stTable;
        }

        ///Constructor definition 2
        public Trading() 
        {
        }


        public List<StockRegister<string, StockType, double, double, double>> FetchStockFromExchange(string symbol)
        {
            return QuerySymbol(symbol);
        }

        /// <summary>
        /// useful for fetching a stock record from the master register (in case multiple records exist)
        /// </summary>
        /// <param name="qSymb"></param>
        /// <returns></returns>
        public List<StockRegister<string, StockType, double, double, double>> QuerySymbol(string qSymb)
        {
            var stockRecords = from record
                               in stockTable
                               where record.symbol == qSymb
                               select record.ReadRegister(); 

            List<StockRegister<string, StockType, double, double, double>> listSr = 
                new List<StockRegister<string, StockType, double, double, double>>();
            foreach (var parameterset in stockRecords)
            {
                listSr.Add(parameterset);
            }
            return listSr;
        }

        ///...calculating the geometric mean
        public double CalcGeometricMean(string qSymb)
        {
            double prod = 1;
            double n = 0;

            foreach (var v in stockTable)
            {
                if (v.symbol.StartsWith(qSymb))
                {
                    foreach(StockTransaction<string, string, TradeIndicator, double, double, DateTime> 
                            tt in v.TransactionTable)
                    {
                        prod *= tt.price;
                        n = n + 1; 
                        ///Console.Write(double.TryParse(tt.qty.ToString(), out d).ToString());
                    }
                }
            }

            return n > 0? Math.Pow(prod, (1/n)): -1;
        }

        ///... calculating the volume weighted stock price
        public double CalcVolWeightedStockPrice(string qSymb, int NoOfMins)
        {
            double num = 0;
            double denum = 0;

            foreach (var v in stockTable)
            {
                if (v.symbol.StartsWith(qSymb))
                {
                    foreach (StockTransaction<string, string, TradeIndicator, double, double, DateTime> tt in v.TransactionTable)
                    {

                        if ((DateTime.Now - tt.time).TotalMinutes <= NoOfMins) // ... within the past 5 minutes
                        {
                            num += tt.price * tt.qty;
                            denum += tt.qty;                            
                        }
                    }
                }
            }

            return denum > 0 ? num/denum : -1;
        }

        ///... calculating the geometric mean and volume weighted stock price for all stocks
        public void GMAndWPForAllStocks(int NoOfMins)
        {
            ///calculating geometric mean and volume weighted price for all stocks
            for (int i = 0; i < stockTable.Length; i++)
            {
                stockTable[i].geometricMean = CalcGeometricMean(stockTable[i].symbol);
                stockTable[i].volumeWeightedPrice = CalcVolWeightedStockPrice(stockTable[i].symbol, NoOfMins);

                ///print
                Console.WriteLine("STOCK {0}, GEOM. MEAN {1}, VOLUME WEIGHTED PRICE {2}",
                    stockTable[i].symbol,
                    stockTable[i].geometricMean > 0 ? stockTable[i].geometricMean.ToString() : "\"UNDEFINED\"", 
                    /// negative numbers depict "undefined"
                    stockTable[i].volumeWeightedPrice > 0 ? stockTable[i].volumeWeightedPrice.ToString() : "\"UNDEFINED\"");
            } 
        }

        ///... find the record index from the master table
        public int FindIndex(string qSymb)
        {
            int ind = -1;
            foreach (var v in stockTable)
            {
                ind++;
                if (v.symbol.StartsWith(qSymb))
                {
                    v.ReadRegister(); break;
                }
            }
            return ind;
        }

        
        ///... reporting all records associated with a specific StockType
        public void QueryStockType(StockType qType)
        {
            var stockRecords = from record
                               in stockTable
                                       where record.type == qType
                                       select record.GetParameters();

            foreach (var paramerset in stockRecords)
                     Console.WriteLine(paramerset);
        }

        ///... reporting all records associated with a specific LastDividend value
        public void QueryLastDividend(double qlastDividend)
        {
            var stockRecords = from record
                               in stockTable
                                       where record.lastDividend == qlastDividend
                                       select record.GetParameters();

            foreach (var paramerset in stockRecords)
                     Console.WriteLine(paramerset);
        }

        ///... reporting all records associated with a specific FixedDividend value
        public void QueryFixedDividend(double qfixedDividend)
        {
            var stockRecords = from record
                               in stockTable
                                       where record.fixedDividend == qfixedDividend
                                       select record.GetParameters();

            foreach (var paramerset in stockRecords)
                     Console.WriteLine(paramerset);
        }

        ///... reporting all records associated with a specific ParValue
        public void QueryParValue(double qparValue)
        {
            var stockRecords = from record
                               in stockTable
                                       where record.parValue == qparValue
                                       select record.GetParameters();

            foreach (var paramerset in stockRecords)
                     Console.WriteLine(paramerset);
        }

        ///... handling how to calculate dividend yield and P/E ratio
        public void CalcDividendAndPEratio(string symbol, string pr)
        {
            double dprice;

            if (double.TryParse(pr, out dprice))
                CalcDividendAndPEratio(symbol, dprice);
        }

        ///... handling how to calculate dividend yield and P/E ratio
        public void CalcDividendAndPEratio(string symbol, double dprice)
        {
               List<StockRegister<string, StockType, double, double, double>> srq = FetchStockFromExchange(symbol);
                for (int i = 0; i < srq.Count; i++)
                {
                    Console.WriteLine("Calculated Dividend Yield: {0} %", 
                        srq[i].CalculateDividendYield(dprice).ToString());

                    if (srq[i].CalculatePEratio(dprice).ToString().StartsWith("-1"))
                        Console.WriteLine("Calculated Price/Earnings Ratio {0} - does not exist!", 
                            srq[i].CalculatePEratio(dprice).ToString());
                    else
                        Console.WriteLine("Calculated Price/Earnings Ratio is {0} ", 
                            srq[i].CalculatePEratio(dprice).ToString());
                }

                Console.WriteLine("________________________________");     
       }

        ///... inputing stock symbol and price to use
        public void InputPrice(string symbol, double dprice)
        {
                bool bflag = false;

                Console.WriteLine("________________________________");
                Console.WriteLine("   GLOBAL BEVERAGE CORPORATION EXCHANGE ");
                Console.WriteLine("________________________________");
                           
                Console.WriteLine("________________________________");
                Console.Write("FETCHING STOCK ... >\nSTOCK SYMBOL: {0}", symbol); 
                FetchStockFromExchange(symbol);

                bflag = String.IsNullOrEmpty(symbol);

                if (!bflag)
                {
                    Console.WriteLine("\nCALCULATING DIVIDEND YIELD AND P/E RATIO ...");
                    Console.Write("{0}'S STOCK PRICE: {1}\n", symbol, dprice); 

                    CalcDividendAndPEratio(symbol, dprice);                    
                }
        }

        /// ... handling trade transactions - query  
        public void Transactions(string symbSource, 
                                string symbTarget, 
                                TradeIndicator indc, 
                                double qty, 
                                double price )
        {
                Console.WriteLine("________________________________");
                Console.WriteLine("  RECORDING AND REPORTING TRADE TRANSACTION(S) BETWEEN {0} AND {1} ... ", 
                    symbSource, symbTarget);
                Console.WriteLine("________________________________\n");

                if (symbSource.Trim().ToUpper().Equals(symbTarget.Trim().ToUpper()))
                    Console.WriteLine("SOURCE SYMBOL AND TARGET SYMBOL MUST NOT BE EQUAL!");
                else
                {  
                    int ind = FindIndex(symbSource);
                    stockTable[ind].TransactionTable.Add(
                        new StockTransaction<string, string, TradeIndicator, double, double, DateTime>
                            (symbSource, symbTarget, indc, qty, price, DateTime.Now));
                    stockTable[ind].QueryTransactions(); //symbol);  
                }
        }       
    }

    class Application
    {
        static void Main(string[] args) 
        {
            /// main program entry point \n
            ///instantiating the StockRegister table with list of all stocks \n
            /// - to be stored in the master table \n
            StockRegister<string, StockType, double, double, double>[] stTable = 
                    new StockRegister<string, StockType, double, double, double>[]
                        {
new StockRegister<string, StockType, double, double, double>("TEA", StockType.Common,     0,  100, 0      ),
new StockRegister<string, StockType, double, double, double>("POP", StockType.Common,     8,  100, 0      ),
new StockRegister<string, StockType, double, double, double>("ALE", StockType.Common,     23,  60, 0      ),
new StockRegister<string, StockType, double, double, double>("GIN", StockType.Preferred,  8,  100, 0.02   ),
new StockRegister<string, StockType, double, double, double>("JOE", StockType.Common,     13, 250, 0      )
                        };

                    ///demonstrate how to supply trade transactions for recording.
                    stTable[2].UseSampleTransactions();

            ///creating and instantiating the application class for handling associated trading logic
            Trading trading = new Trading(stTable);

                    ///show how to provide a price value as input for a given stock
                    trading.InputPrice(stTable[2].symbol, 10);

                    ///...recording trade transactions between pairs of stocks
                    ///note: invalid transactions are ignored
                    trading.Transactions(stTable[0].symbol, "JOE", TradeIndicator.Sell, 120, 15);      
                    trading.Transactions(stTable[2].symbol, "GIN", TradeIndicator.Buy, 49, 9);
                    trading.Transactions("JOE", "POP", TradeIndicator.Sell, 10, 5);
                    trading.Transactions("POP", "POP", TradeIndicator.Sell, 25, 5); // invalid transaction
                    trading.Transactions("ALE", "TEA", TradeIndicator.Buy, 170, 22);

                    Console.WriteLine("");
                    ///calculating geometric mean and volume weighted price for a specific stock, i.e. "ALE"
                    Console.WriteLine("Calculated Geometric Mean: {0}",trading.CalcGeometricMean("ALE"));
                    Console.WriteLine("Calculated Volume Weighted Stock Price (past 5 minutes): {0}", 
                                trading.CalcVolWeightedStockPrice("ALE", 5));
                    Console.WriteLine("");

                    ///calculating geometric mean and volume weighted price for all stocks
                    trading.GMAndWPForAllStocks(5);               

                    ///readkey 
                    Console.ReadKey();
        }
    }
}
